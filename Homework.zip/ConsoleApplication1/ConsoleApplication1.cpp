﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <locale.h>

using namespace std;

class Volokno {
public:
    string voloknoFirstIndicator;
    string voloknoSecondIndicator;
    string voloknoThirdIndicator;
    string voloknoForthIndicator;
    string voloknoName;
};

int read_file(Volokno*& voloknoArr, int& size) {
    size = 0;

    ifstream file("volokna_tabl.csv");
    if (!file.is_open()) {
        cerr << "Ошибка: Невозможно открыть файл.\n";
        return -1;
    }

    string line;
    // Проход 1: определение количества строк в файле
    while (getline(file, line)) {
        size++;
    }

    // Переходим в начало файла
    file.clear();
    file.seekg(0, ios::beg);

    // Проход 2: считывание данных
    voloknoArr = new Volokno[size];
    for (int i = 0; i < size; ++i) {
        getline(file, line);
        stringstream ss(line);
        getline(ss, voloknoArr[i].voloknoFirstIndicator, ';');
        getline(ss, voloknoArr[i].voloknoSecondIndicator, ';');
        getline(ss, voloknoArr[i].voloknoThirdIndicator, ';');
        getline(ss, voloknoArr[i].voloknoForthIndicator, ';');
        getline(ss, voloknoArr[i].voloknoName, ';');
    }

    file.close();

    return 1;
}

int main() {
    setlocale(LC_ALL, "RUS");
    Volokno* voloknoArray = nullptr;
    int size = 0;

    int result = read_file(voloknoArray, size);

    if (result == 1) {
        // Выводим данные для проверки
        for (int i = 0; i < size; ++i) {
            cout << "Volokno " << i + 1 << ": "
                << voloknoArray[i].voloknoFirstIndicator << ", "
                << voloknoArray[i].voloknoSecondIndicator << ", "
                << voloknoArray[i].voloknoThirdIndicator << ", "
                << voloknoArray[i].voloknoForthIndicator << ", "
                << voloknoArray[i].voloknoName << endl;
        }
    }
    else {
        cerr << "Ошибка при чтении файла." << endl;
    }

    // Освобождаем выделенную память
    delete[] voloknoArray;

    return 0;
}
